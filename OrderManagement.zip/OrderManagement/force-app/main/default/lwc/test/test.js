import { LightningElement,track} from 'lwc';
import getProductList from '@salesforce/apex/CustomOrderController.getProductList';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
import createOrder from '@salesforce/apex/CustomOrderController.createOrder';
export default class customSearch extends LightningElement {
    @track products;
    @track value = '';
    @track selected = [];
    @track bShowModal = false;
    @track quan;
    @track show = false;
    @track discount;
    @track accountId='';
    @track totalAmount=0;
    @track orderAmount=0;
    @track showtable = false;
    
    @track isModalOpen=false;
     columns = [
        { label: 'Name', fieldName: 'Name' },
        { label: 'Brand', fieldName: 'Brand' },
        { label: 'Stock', fieldName: 'Stock', type: 'number' },
        { label: 'MRP', fieldName: 'MRP', type: 'currency' },
    ];
    get options() {
        return [
            { label: 'Name', value: 'Name' },
            { label: 'Brand', value: 'Brand' },
            {label:'MRP', value: 'MRP'}
        ];
    }

    acc(event){
        this.accountId = event.target.value;
    }
    save()
    {
        for(var product of this.selected)
     {           
         product.MRP=product.MRP - (product.MRP * product.discount / 100);
         
         console.log("Discounted price:" + product.MRP);
     }
     for(var product of this.selected)
     {
        product.orderAmount=product.MRP * (product.Desired_quantity);
        console.log("orderAmount: "+ product.orderAmount);
     }
     for(var i of this.selected)
     {
         this.totalAmount=this.totalAmount+i.orderAmount;
         console.log("totalAmount:"+ this.totalAmount);
     }
        var index = 0;
        for(var i of this.selected){
            if(i.Desired_quantity>0)
            {
                if(i.Desired_quantity>10 )
                {
                    if(i.Stock-i.Desired_quantity>0){
                    this.selected[index].Desired_quantity=parseInt(this.selected[index].Desired_quantity)+1;
                    index++;
                    }
                    else{
                        const event = new ShowToastEvent({
                            variant: 'error',
                            message: 'Incorrect Quantity!1',
                        });
                        this.dispatchEvent(event);
                        break;
                    }
                }
                else{
                    index++;
                }
            }
            else{
                const event = new ShowToastEvent({
                    variant: 'error',
                    message: 'Incorrect Quantity!2',
                });
                this.dispatchEvent(event);
                break;
            }
        }
        console.log("modalOpen")
            this.isModalOpen=true;
    }
    handlechange(event){
        this.value = event.target.value;
    }
    
    updateSeachKey(event) {
        this.sVal = event.target.value;
    }

    updateQuantity(event){
        var index = event.target.dataset.targetId;
        var inputfield=this.template.querySelectorAll(".test")[index];
        
        if(event.target.value < this.selected[index].Stock && event.target.value > 0){
            this.selected[index].Desired_quantity = event.target.value;
            inputfield.setCustomValidity("");
        }
        else{
            inputfield.setCustomValidity("Quantity Should Be less than stock");
        }
        inputfield.reportValidity();
        console.log("updated selected products:=>" + JSON.stringify(this.selected));
    }

    handleSearch() {
        if (this.sVal !== '') {
            getProductList({
                    searchKey: this.sVal,
                    inSearch: this.value
                })
                .then(result => {
                    let mydata = [];
                    console.log(JSON.stringify(result));
                    result.forEach(element => {
                        let newObject = new Object();
                        newObject.id = element.Product2.Id;
                        newObject.Name = element.Product2.Name;
                        newObject.Brand = element.Product2.Brand__c;
                        newObject.Stock = element.Product2.Stock_Quantity__c;
                        newObject.Desired_quantity = 0;
                        newObject.discount=0;
                        newObject.orderAmount=0;
                        newObject.MRP = element.UnitPrice;
                        newObject.PriceBookEntryId=element.Id;
                        mydata.push(newObject);
                    });
                    this.products = mydata;
                    this.showtable = true;
                    console.log(JSON.stringify(this.products));
                })
                .catch(error => { 
                    const event = new ShowToastEvent({
                        title: 'Error',
                        variant: 'error',
                        message: error.body.message,
                    });
                    this.dispatchEvent(event);  
                    this.products = null;
                });
        } else {
            const event = new ShowToastEvent({
                variant: 'error',
                message: 'Search text missing..',
            });
            this.dispatchEvent(event);
        }
    }
    handleAdd(){
        var n=this.template.querySelector('lightning-datatable').getSelectedRows().length;
        var i;
        for(i = 0; i < n; i++)
        {
            this.selected.push(this.template.querySelector('lightning-datatable').getSelectedRows()[i]);
        }
        console.log("structure of selected"+JSON.stringify(this.selected));
        this.show = true;
    }
    order(){
        var size=this.selected.length;
        console.log("size: "+size);
     
        createOrder({
            selectedProducts: JSON.stringify(this.selected),
            priceBookId: '01s2x000000srDLAAY',
            accId:this.accountId
        })
        .then(result => {
            console.log('Order Id : ' + result);
            const event = new ShowToastEvent({
                variant: 'success',
                message: 'Order Created',
            });
            this.dispatchEvent(event);
        });
            console.log(JSON.stringify("Groot"+this.selected));
            console.log("Groot accid"+this.accountId);
        }
    clearOrder(){
        this.selected = [];
        this.show = false;
        console.log(JSON.stringify(this.selected));
    }
    updateDiscount(event){
        var index = 0;
        for(var i of this.selected){
            if(event.target.name==i.id){
                break;
            }
            index++;
        }
             this.selected[index].discount=event.target.value;
    }
    remove(event){
        let list = [];
        for(var i of this.selected){
            console.log(JSON.stringify(i));
            if(event.target.name==i.id){
                continue;
            }
            list.push(i);
        }
        this.selected = list;
        if(this.selected.length == 0)
            this.show = false;
        console.log("new selected"+ JSON.stringify(this.selected));
    }
    openModal() {
        this.isModalOpen = true;
    }
    closeModal() {
        window.location.reload();
        this.isModalOpen = false;
    }
}