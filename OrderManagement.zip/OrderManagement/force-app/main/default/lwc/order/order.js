import { LightningElement } from 'lwc';
import getOrder from '@salesforce/apex/OrderController.getOrder';
import OrderNumber from '@salesforce/schema/Order.OrderNumber';
import Status from '@salesforce/schema/Order.Status';

export default class Order extends LightningElement {



    fields = [OrderNumber, Status];
    columns = [
        { label: 'Order Number', fieldName: 'OrderNumber' },
        { label: 'Status', fieldName: 'Status'}
    ];

    bShowModal = false;
    showNew = false;

    orderList;


    connectedCallback(){
        this.refreshList();
     }

     refreshList(){
         getOrder()
         .then(result=>{
             this.orderList = result;
         })
     }
     createOrder(){
         this.bShowModal = true;
         this.showNew = true;
     }


     closeModal(){
         this.bShowModal = false;
     }




}