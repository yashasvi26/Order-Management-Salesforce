import { LightningElement } from 'lwc';

export default class Edit extends LightningElement {}