import { LightningElement, wire, track} from 'lwc';
import getProducts from '@salesforce/apex/OrderController.getProducts';
//import createOrder from '@salesforce/apex/OrderController.createOrder';
//import confirmSaveOrder from '@salesforce/apex/OrderController.confirmSaveOrder';


export default class Order_Create extends LightningElement {

    productList;
    searchVal;showSearchList=false;
    selectedProductList=[];
    selectedTableToggle=true;
    showFinalTable=false;

    handleSearch(event){
        if(event.target.value.length!=0){
            getProducts({searchVal:event.target.value,priceBookId:'01s2w000004MN8WAAW'})
            .then(result=>{
                this.productList=JSON.parse(result);
            });
            this.showSearchList=true;
        }
        if(event.target.value.length==0){
            this.showSearchList=false;
        }
    }

    addProduct(event){
        this.selectedTableToggle=false;
        var id=event.target.value;
        var index = -1;
        var selectedproduct=new Object();
        for(var product of this.productList){
            index++;
            if(id==product.Id){
                selectedproduct.Id=id;
                selectedproduct.Name=product.Name;
                selectedproduct.ProductCode=product.ProductCode;
                selectedproduct.Brand_c=product.Brand_c;
                selectedproduct.Stock_Quantity_c=product.Stock_Quantity_c;
                selectedproduct.Quantity='1';
                selectedproduct.UnitPrice=product.ListPrice;
                break;
            }
        }
        if(!this.selectedProductList.some(item => item.Id === selectedproduct.Id)){
            this.selectedProductList.push(selectedproduct);
        }
        this.showSearchList=false;
        this.selectedTableToggle=true;
    }

    updateQuantity(event){
        var index = -1;
        for(var product of this.selectedProductList){
            index++;
            if(event.target.name==product.Id){
                break;
            }
        }
        this.selectedProductList[index].Quantity=event.target.value;
    }

    removeClicked(event){
        var id=event.target.value;
        for(var product of this.selectedProductList){
            if(id==product.Id){
                const index = this.selectedProductList.indexOf(product);
                this.selectedProductList.splice(index,1)
            }
        }
        this.selectedTableToggle=false;
        this.selectedTableToggle=true;
    }
    
    saveClicked(){
        for(var product of this.selectedProductList){
            var selectedproduct=new Object();
            if(product.Quantity>10){
                selectedproduct.Id=id;
                selectedproduct.Name=product.Name;
                selectedproduct.ProductCode=product.ProductCode;
                selectedproduct.Brand_c=product.Brand_c;
                selectedproduct.Stock_Quantity_c=product.Stock_Quantity_c;
                selectedproduct.Quantity='1';
                selectedproduct.UnitPrice=0; 
                this.selectedProductList.push(selectedproduct);
            }
        }
        this.showFinalTable=true;
    }
}